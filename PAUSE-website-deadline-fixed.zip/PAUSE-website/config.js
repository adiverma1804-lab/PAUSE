// PAUSE public website configuration.
// Customer project requests are submitted to the connected Formspree form.
// Keep payment secret keys, database service-role keys, and passwords out of this file.
window.PAUSE_CONFIG = {
  formEndpoint: "https://formspree.io/f/mnpplyaj",
  contactEmail: ""
};
