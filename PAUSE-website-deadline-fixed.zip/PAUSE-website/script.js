(() => {
  "use strict";

  const config = window.PAUSE_CONFIG || {};
  const menuBtn = document.getElementById("menuBtn");
  const navLinks = document.getElementById("navLinks");
  const form = document.getElementById("orderForm");
  const status = document.getElementById("formStatus");
  const year = document.getElementById("year");

  if (year) year.textContent = new Date().getFullYear();

  if (menuBtn && navLinks) {
    menuBtn.addEventListener("click", () => {
      const isOpen = navLinks.classList.toggle("open");
      menuBtn.setAttribute("aria-expanded", String(isOpen));
      menuBtn.setAttribute("aria-label", isOpen ? "Close navigation menu" : "Open navigation menu");
    });
    navLinks.querySelectorAll("a").forEach(link => {
      link.addEventListener("click", () => {
        navLinks.classList.remove("open");
        menuBtn.setAttribute("aria-expanded", "false");
        menuBtn.setAttribute("aria-label", "Open navigation menu");
      });
    });
    document.addEventListener("click", event => {
      if (!navLinks.contains(event.target) && !menuBtn.contains(event.target)) {
        navLinks.classList.remove("open");
        menuBtn.setAttribute("aria-expanded", "false");
        menuBtn.setAttribute("aria-label", "Open navigation menu");
      }
    });
  }

  document.querySelectorAll("[data-service]").forEach(link => {
    link.addEventListener("click", () => {
      const select = document.getElementById("serviceSelect");
      if (select) select.value = link.dataset.service;
    });
  });

  // Keep the deadline date picker usable and prevent past dates.
  const deadline = form && form.querySelector('input[name="deadline"]');
  function updateDeadlineMinimum() {
    if (!deadline) return;
    const now = new Date();
    const localDate = new Date(now.getTime() - now.getTimezoneOffset() * 60000)
      .toISOString().slice(0, 10);
    deadline.min = localDate;
  }
  updateDeadlineMinimum();

  function showStatus(message, type) {
    if (!status) return;
    status.textContent = message;
    status.className = "form-status " + (type || "");
  }

  function validateForm() {
    if (!form) return false;
    const required = [...form.querySelectorAll("[required]")];
    for (const field of required) {
      if (!field.value.trim()) {
        field.focus();
        showStatus("Please complete all required fields.", "error");
        return false;
      }
      if (field.type === "email" && !field.validity.valid) {
        field.focus();
        showStatus("Please enter a valid email address.", "error");
        return false;
      }
    }
    const link = form.querySelector('input[name="filelink"]');
    if (link && link.value.trim() && !link.validity.valid) {
      link.focus();
      showStatus("Please enter a valid file-sharing URL, including https://.", "error");
      return false;
    }
    if (deadline && deadline.value && deadline.min && deadline.value < deadline.min) {
      deadline.focus();
      showStatus("Please choose today or a future deadline.", "error");
      return false;
    }
    return true;
  }

  if (form) {
    form.addEventListener("submit", async event => {
      event.preventDefault();
      showStatus("", "");
      if (!validateForm()) return;

      // Simple honeypot spam check. Legitimate users never see this field.
      const honeypot = form.querySelector('input[name="_gotcha"]');
      if (honeypot && honeypot.value) {
        showStatus("Your request could not be submitted. Please try again.", "error");
        return;
      }

      const endpoint = (config.formEndpoint || "").trim();
      const email = (config.contactEmail || "").trim();
      const button = form.querySelector('button[type="submit"]');
      const originalButtonText = button ? button.innerHTML : "";

      if (button) {
        button.disabled = true;
        button.textContent = "Sending request…";
      }

      try {
        if (endpoint) {
          if (!/^https:\/\/formspree\.io\/f\/[A-Za-z0-9]+$/i.test(endpoint)) {
            throw new Error("The Formspree endpoint in config.js looks incorrect. Please check and save it again.");
          }
          const controller = new AbortController();
          const timeout = setTimeout(() => controller.abort(), 20000);
          let response;
          try {
            // FormData is the standard browser-friendly Formspree submission format.
            response = await fetch(endpoint, {
              method: "POST",
              body: new FormData(form),
              headers: { "Accept": "application/json" },
              signal: controller.signal
            });
          } finally {
            clearTimeout(timeout);
          }
          let result = {};
          try { result = await response.json(); } catch (_) {}
          if (!response.ok) {
            const detail = result.errors && result.errors.map(item => item.message).join(" ");
            throw new Error(detail || "We couldn't send your request. Please check your Formspree form and try again.");
          }
          form.reset();
          updateDeadlineMinimum();
          showStatus("Your request has been sent successfully. Thank you! We'll contact you using the email you provided.", "success");
        } else if (email) {
          // Fallback: opens the visitor's email app. It does not submit silently.
          const data = Object.fromEntries(new FormData(form).entries());
          const subject = encodeURIComponent("New PAUSE project request — " + data.service);
          const body = encodeURIComponent(
            "Name: " + data.name + "\nEmail: " + data.email + "\nService: " + data.service +
            "\nBudget: " + (data.budget || "Not specified") + "\nDeadline: " + (data.deadline || "Not specified") +
            "\nFile link: " + (data.filelink || "Not provided") + "\n\nTask details:\n" + data.details
          );
          window.location.href = "mailto:" + encodeURIComponent(email) + "?subject=" + subject + "&body=" + body;
          showStatus("Your email app should open with the request prepared. Please press Send in your email app to complete it.", "success");
        } else {
          showStatus("The request form is not connected yet. Add your Formspree endpoint in config.js, then redeploy the website. No request has been sent.", "error");
        }
      } catch (error) {
        const message = error.name === "AbortError"
          ? "The request timed out. Please check your internet connection and try again."
          : (error.message || "Something went wrong. Please try again.");
        showStatus(message, "error");
      } finally {
        if (button) {
          button.disabled = false;
          button.innerHTML = originalButtonText;
        }
      }
    });
  }
})();