# PAUSE — Digital Services Website

Responsive dark-theme website for PAUSE, a digital services business.

## Included
- Responsive landing page for video editing, Reels/Shorts, photo editing, automation, presentations, graphic design and custom tasks.
- Working mobile navigation, service-to-order selection, client-side validation and accessible form status messages.
- Quote-first order workflow: customer submits a request; you review it and confirm the price and timeline before asking for payment.

## Run locally
Open `index.html` in a browser, or use the Live Server extension in VS Code.

## Connect customer requests (required before launch)
1. Create a form at https://formspree.io/.
2. Verify your email address in Formspree if requested.
3. Copy the form endpoint. It looks like `https://formspree.io/f/xxxxxxxx`.
4. Open `config.js` and paste it into `formEndpoint`.
5. Save and redeploy the complete folder to Vercel.
6. Submit a test request and confirm it arrives in your inbox.

Example:
```js
window.PAUSE_CONFIG = {
  formEndpoint: "https://formspree.io/f/xxxxxxxx",
  contactEmail: ""
};
```

Optional email-app fallback:
- If you do not have a Formspree endpoint, you may set `contactEmail` to your public business email.
- The form then opens the visitor's email application with the request prepared. The visitor must press Send. This is not automatic delivery.
- Do not publish the site with both values blank if you expect to receive orders.

## Payments
No live payment processing is included in this static website. The intended safe workflow is:
1. Customer submits a task.
2. You review it and confirm scope, price and delivery time.
3. You send a payment link from your payment provider.
4. Start work after payment is confirmed.

For integrated checkout, use a payment provider such as Razorpay with a secure server-side backend. Never place secret API keys in browser JavaScript or `config.js`. Verify payment status server-side before marking an order as paid.

## Before launch
- Connect and test Formspree.
- Add your real contact information.
- Publish privacy, terms, refund and cancellation policies.
- Decide your delivery and revision policy.
- Set up a secure backend and payment verification if you need customer accounts, order tracking or on-site checkout.

## Deploy on Vercel
1. Extract this ZIP.
2. Import the folder/repository into Vercel (or push it to GitHub and import the repository).
3. For this plain HTML/CSS/JS site, select **Other** as the framework preset if asked; no build command is needed.
4. Set the output directory to `.` if Vercel asks for one.
5. Deploy. After editing files, redeploy or push the updated Git commit.
